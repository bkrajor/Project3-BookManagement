const express = require('express')
const router = express.Router()
const userController = require('../controllers/userController')
const bookController = require('../controllers/bookController')
const reviewController = require('../controllers/reviewController')
const { authenticate, authorize } = require('../middleware/auth')

// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

// ---------User's APIs------------
router.post('/register', userController.createUser)

router.post('/login', userController.userlogin)

// ---------Book's APIs-------------
router.post('/books', authenticate, bookController.createBook)

router.get('/books', authenticate, bookController.getBooks)

router.get('/books/:bookId', authenticate, bookController.getBookById)

router.put('/books/:bookId', authenticate, authorize, bookController.updateBook)

router.delete('/books/:bookId', authenticate, authorize, bookController.deleteBookById)

// ----------Review's APIs------------
router.post('/books/:bookId/review', authenticate, reviewController.createReview)

router.put('/books/:bookId/review/:reviewId', authenticate, reviewController.updateReview)

router.delete('/books/:bookId/review/:reviewId', authenticate, reviewController.deleteReview)

// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


module.exports = router
